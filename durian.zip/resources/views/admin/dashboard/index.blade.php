@extends('layouts.admin')

@section('content')

<div class="container-fluid">
   <div class="row">
      <div class="col-sm-12">
         <div class="card">
            <div class="card-header">
	              <h5>Dashboard</h5>
            </div>
            <div class="card-body">
               To be updated Soon
            </div>
         </div>
      </div>
   </div>
</div>

@stop