

$('.add-product img').elevateZoom({
    zoomType: "inner",
    cursor: "crosshair"
});
























