
<style type="text/css">

</style>


<?php $__env->startSection('content'); ?>





   
    <section class="ftco-section contact-section bg-light py-5">
      <div class="container">
        <div class="row block-9">
          <div class="col-md-6 d-flex mx-auto">


            <form action="#" class="bg-white p-5 contact-form">
              
              <div class="form-group">
                <input type="email" class="form-control" placeholder="Your Email">
              </div>
              <div class="form-group">
                <input type="password" class="form-control" placeholder="Password">
              </div>
             
              <div class="form-group">
                <button type="submit" class="btn btn-primary py-2 px-3">Login</button>
              </div>

              <div class="pt-3">
                <a class="" href="<?php echo e(url('/register')); ?>">Do not account?</a>
              </div>

            </form>

            


          </div>         
        </div>
      </div>
    </section>
   

  

<?php $__env->stopSection(); ?>


<?php $__env->startSection('js'); ?>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\durian\resources\views/shopping/login.blade.php ENDPATH**/ ?>