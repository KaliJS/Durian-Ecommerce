<!-- footer start-->
<div class="footer-wrap pd-20 mb-20 card-box">
    Copyright 2020 <a href="#" target="_blank">Durians</a>
</div>
<!-- footer end--><?php /**PATH C:\xampp\htdocs\durian\resources\views/includes/footer.blade.php ENDPATH**/ ?>