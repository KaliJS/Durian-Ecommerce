


<?php $__env->startSection('css'); ?>

<style>
    .variant_remove{
        margin-top: 33px;
    }
    .product_variant{
       margin-bottom: 30px;
       padding-bottom: 20px;
       border-bottom: 2px solid rebeccapurple;
    }
</style>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>

<div class="pd-20 card-box mb-30">
    <div class="clearfix">
        <div class="pull-left mb-20">
            <h4 class="text-dark h4">Update Product</h4>
            
        </div>
        
    </div>
    <form class="form-horizontal"  action="<?php echo e(route('products.update',$product)); ?>" method="POST" enctype="multipart/form-data">      
       <?php echo method_field('PUT'); ?>
       <?php echo csrf_field(); ?>
        <div class="form-group row">
            <label class="col-sm-12 col-md-2 col-form-label">Product Name</label>
            <div class="col-sm-12 col-md-10">
                <input class="form-control" type="text" value="<?php echo e($product->name); ?>" name="name" placeholder="Name" required>
            </div>
        </div>
        
        <div class="form-group row">
            <label class="col-sm-12 col-md-2 col-form-label">Description</label>
            <div class="col-sm-12 col-md-10 html-editor">
                <textarea rows="2" name="description" class="textarea_editor form-control border-radius-0" required><?php echo e($product->description); ?></textarea>
            </div>
        </div>

        <div class="form-group row">
            <label class="col-sm-12 col-md-2 col-form-label">SKU</label>
            <div class="col-sm-12 col-md-10">
                <input class="form-control" value="<?php echo e($product->sku); ?>" type="text" name="sku" required>
            </div>
        </div>

        <div class="form-group row ">
            <label class="col-sm-12 col-md-2 col-form-label">Category</label>
            <div class="col-sm-12 col-md-10">
              <select class="custom-select col-12" name="category_id" required>
                <option selected disabled>Select</option>
                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($category->id); ?>" <?php echo e($category->id==$product->category_id?'Selected':''); ?>><?php echo e($category->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </select>
            </div>
         </div>


         <div class="add_varient">

            <?php $__currentLoopData = $product->variants; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class='row product_variant'>
               <div class='form-group col-md-2 col-sm-6'>
                  <label>Unit Name</label>
                  <select class='custom-select ' name='unit_id[]' required>
                     <option selected disabled>Select</option>
                     <?php $__currentLoopData = $units; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $unit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value='<?php echo e($unit->id); ?>' <?php echo e($v->unit_id==$unit->id?'Selected':''); ?>><?php echo e($unit->name); ?></option>
                     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </select>
               </div>
               <div class='col-md-2 col-sm-6'>
                  <div class='form-group'><label>Quantity</label><input type='number' name='quantity[]' class='form-control' value="<?php echo e($v->quantity); ?>" required></div>
               </div>
               <div class='col-md-2 col-sm-6'>
                  <div class='form-group'><label>MRP Price</label><input type='number' name='mrp_price[]' class='form-control' value="<?php echo e($v->mrp_price); ?>" required></div>
               </div>
               <div class='col-md-2 col-sm-6'>
                  <div class='form-group'><label>Selling Price</label><input type='number' name='selling_price[]' class='form-control' value="<?php echo e($v->selling_price); ?>" required></div>
               </div>
               
               <div class='col-md-2 col-sm-6'>
                  <div class='form-group'><label>In Stock</label>
                    
                          <select class="custom-select2 form-control" name="in_stock[]" style="width: 100%;">
                              
                              <option value="1" <?php echo e($v->in_stock=='1'?'Selected': ''); ?>>Yes</option>
                              <option value="0" <?php echo e($v->in_stock=='0'?'Selected': ''); ?>>No</option>
                              
                          </select>
                      
                  </div>
               </div>

               <div class='col-md-2 col-sm-12'>
                  <button class="btn btn-danger variant_remove mx-auto"  type="button"><i class="icon-copy dw dw-trash"></i></button>
               </div>
              


            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


         </div>


         <div class="row text-center">
            <button class="btn btn-primary variant mx-auto mb-20" type="button"><i class="icon-copy dw dw-add"></i> Add Product Variants</button>
         </div>

         <div class="row my-3">
          <div class=" col-md-3">All Images</div>
          <div class=" col-md-9">
            <?php $__currentLoopData = explode(',',$product->images); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="d-flex flex-row">
              <div class="col-md-8">
                <img src="<?php echo e(asset('uploads/products/'.$image)); ?>" class="img-fluid" width="100px">
              </div>
              <div class="col-md-4">
                <input type="" class="get_product_id" value="<?php echo e($product->id); ?>" hidden>
                <button class="btn btn-danger deleteImage" id="<?php echo e($image); ?>" type="button">Remove</button>
              </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </div>
        </div>

         <div class="form-group row">
            <label class="col-sm-12 col-md-2 col-form-label">Images</label>
            <div class="col-sm-12 col-md-10">
               <input type="file" multiple name="images[]" class="form-control-file form-control height-auto">
            </div>
         </div>

         <div class="form-group row">
            <label class="col-sm-12 col-md-2 col-form-label">Status</label>
            <div class="col-sm-12 col-md-10">
                <select class="custom-select2 form-control" name="status" style="width: 100%;">
                    
                    <option value="1" <?php echo e($product->status=='1'?'Selected': ''); ?>>Active</option>
                    <option value="0" <?php echo e($product->status=='0'?'Selected': ''); ?>>Not Active</option>
                    
                </select>
            </div>
        </div>

        <button class="btn btn-success" type="submit">Update</button>

    </form>
    
</div>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('js'); ?>

        <script type="text/javascript">

            $(document).on("click",".variant",function(){
                
                  $(".add_varient").append(`<div class='row product_variant'>
                        <div class='form-group col-md-3 col-sm-6'>
                           <label>Unit Name</label>
                           <select class='custom-select ' name='unit_id[]' required>
                              <option selected disabled>Select</option>
                              <?php $__currentLoopData = $units; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $unit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><option value='<?php echo e($unit->id); ?>' <?php echo e($unit->id==Request::old('unit_id')?'selected':''); ?>><?php echo e($unit->name); ?></option><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                           </select>
                        </div>
                        <div class='col-md-3 col-sm-6'>
                           <div class='form-group'><label>Quantity</label><input type='number' name='quantity[]' class='form-control' required></div>
                        </div>
                        <div class='col-md-2 col-sm-6'>
                           <div class='form-group'><label>MRP Price</label><input type='number' name='mrp_price[]' class='form-control' required></div>
                        </div>
                        <div class='col-md-2 col-sm-6'>
                           <div class='form-group'><label>Selling Price</label><input type='number' name='selling_price[]' class='form-control' required></div>
                        </div>
                        
                        <div class='col-md-2 col-sm-12'>
                           <button class="btn btn-danger variant_remove mx-auto" style='margin-top:33px;' type="button"><i class="icon-copy dw dw-trash"></i></button>
                        </div>
                        
                     </div>`);

                  //$("select").select2();
            });


            $(document).on("click",".variant_remove",function(){
               
               $(this).parent().parent().fadeOut(function(){
                  $(this).remove();
               }); 
            });

            $(document).on("click",".deleteImage",function(){
                const el = this;
                const product_id = $('.get_product_id').val();
                const image_name=this.id;
                $.ajax({
                    method:'POST',
                    url:`/admin/products/getDeleteSelectedImages`,
                    data:{image_name,product_id,"_token":"<?php echo e(csrf_token()); ?>"},
                    encode  : true
                }).then(response=>{
                    if(response){
                         $(el).parent().parent().css('background','tomato');
                         $(el).parent().parent().fadeOut(function(){
                            $(this).remove();
                         });            
                    }
                }).fail(error=>{
                    console.log('error',error);
                });
            });

            
        </script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\durian\resources\views/admin/products/edit.blade.php ENDPATH**/ ?>