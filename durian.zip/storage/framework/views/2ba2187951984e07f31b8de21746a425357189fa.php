    <nav class="navbar navbar-expand-lg navbar-dark ftco_navbar bg-dark ftco-navbar-light" id="ftco-navbar">
        <div class="container">
          <a class="navbar-brand" href="<?php echo e(url('/')); ?>">Vegefoods</a>
          <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#ftco-nav" aria-controls="ftco-nav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="oi oi-menu"></span> Menu
          </button>

          <div class="collapse navbar-collapse" id="ftco-nav">
            <ul class="navbar-nav ml-auto">
              <li class="nav-item active"><a href="<?php echo e(url('/')); ?>" class="nav-link">Home</a></li>
              <li class="nav-item"><a href="<?php echo e(url('/shop')); ?>" class="nav-link">Shop</a></li>
              <li class="nav-item"><a href="<?php echo e(url('/category')); ?>" class="nav-link">Category</a></li>
              <li class="nav-item"><a href="#" class="nav-link">About</a></li>
              <li class="nav-item"><a href="#" class="nav-link">Contact</a></li>

              <?php if(Route::has('login')): ?>
                
                  <?php if(auth()->guard()->check()): ?>
                    <li class="nav-item"><a href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault(); document.getElementById('logout-form').submit();"  class="nav-link"><i class="dw dw-logout"></i> <?php echo e(__('Logout')); ?></a>
                      <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                        <?php echo csrf_field(); ?>
                      </form></li>
                  <?php else: ?>
                      <li class="nav-item"><a href="<?php echo e(route('login')); ?>" class="nav-link">Login</a></li>

                  <?php endif; ?>
                
              <?php endif; ?>


              <li class="nav-item cta cta-colored"><a href="<?php echo e(url('/cart')); ?>" class="nav-link"><span class="icon-shopping_cart" id="cart_count" style="font-size: 17px;">[<?php echo e(session()->has('cart')?count(session()->get('cart')):"0"); ?>]</span></a></li>

            </ul>
          </div>
        </div>
      </nav>
    <!-- END nav -->

<?php /**PATH C:\xampp\htdocs\durian\resources\views/includes/shopping/header.blade.php ENDPATH**/ ?>