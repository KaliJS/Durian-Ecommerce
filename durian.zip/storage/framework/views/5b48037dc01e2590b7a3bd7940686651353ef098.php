

<?php $__env->startSection('content'); ?>

<!-- Simple Datatable start -->
   <div class="card-box mb-30">
      <div class="pd-20">
         <h4 class="text-dark h4">Products List</h4>
         <div class="row">
            <div class="col-md-6">
               <a href="<?php echo e(route('products.create')); ?>" class="btn btn-primary"><i class="fa fa-plus"></i> Add New Product</a>
            </div>
         </div>
      </div>
      <div class="pb-20">
         <table class="data-table table stripe hover nowrap">
            <thead>
               <tr>
                  <th class="table-plus datatable-nosort">Id</th>
                  <th>Name</th>
                  <th>Variants</th>
                  <th>SKU</th>
                  <th>Status</th>            
                  <th>Category</th>
                  <th>Images</th>
                  <th class="datatable-nosort">Action</th>
               </tr>
            </thead>
            <tbody>
               
               <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
               <tr>
                  <td class="table-plus"><?php echo e($c->id); ?></td>
                  
                  <td><?php echo e($c->name); ?> </td>
                  
                  <td>


                    <div class="col-md-4 col-sm-12">
                        <div class="pd-20 height-100-p">
                          <div class="badge badge-success">
                           <a href="#" class="btn-block text-white" data-toggle="modal" data-target="#success-modal<?php echo e($c->id); ?>" type="button">
                              <i class="dw dw-eye"></i> View
                           </a>
                         </div>
                           <div class="modal fade" id="success-modal<?php echo e($c->id); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
                              <div class="modal-dialog modal-dialog-centered" role="document">
                                 <div class="modal-content">
                                          <div class="modal-header">
                                             <h6 class="modal-title" id="myLargeModalLabel">Variants List</h6>
                                             <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                                          </div>
                                          <div class="modal-body">
                                             <div class="table-responsive">
                                                <table class="table table-striped">
                                                  <thead>
                                                    <tr>
                                                      <th scope="col">Quantity</th>
                                                      <th scope="col">Unit</th>
                                                      <th scope="col">MRP Price</th>
                                                      <th scope="col">Selling Price</th>
                                                      <th scope="col">In Stock</th>
                                                    </tr>
                                                  </thead>
                                                  <tbody>
                                                   <?php $__currentLoopData = $c->variants; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <tr>
                                                      <th><?php echo e($v->quantity); ?></th>
                                                      <th><?php echo e($v->unit->name); ?></th>
                                                      <th>$<?php echo e($v->mrp_price); ?></th>
                                                      <th>$<?php echo e($v->selling_price); ?></th>
                                                      <th class="badge <?php echo e($v->in_stock=='1'? 'badge-success':'badge-danger'); ?>"><?php echo e($v->in_stock=='1'?'Yes':'No'); ?></th>
                                                    </tr>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                  </tbody>
                                                </table>
                                             </div>
                                          </div>
                                          
                                       </div>
                              </div>
                           </div>
                        </div>
                     </div>


                  </td>
                  <td><?php echo e($c->sku); ?></td>
                  <td><?php echo e($c->status=='1'?'Active':'Not Active'); ?></td>
                  
                  <td><?php echo e($c->category->name); ?></td>

                  <td>
                     <?php $__currentLoopData = explode(',',$c->images); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($loop->first): ?>
                           <img src="<?php echo e(asset('uploads/products/'.$image)); ?>" class="img-fluid d-block" width="80px;">
                        <?php endif; ?>
                     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                  </td>
                  
                  <td>
                     <div class="dropdown">
                        <a class="btn btn-link font-24 p-0 line-height-1 no-arrow dropdown-toggle" href="#" role="button" data-toggle="dropdown">
                           <i class="dw dw-more"></i>
                        </a>
                        <div class="dropdown-menu dropdown-menu-right dropdown-menu-icon-list">
                           <a class="dropdown-item" href="<?php echo e(route('products.edit',$c)); ?>"><i class="dw dw-edit2"></i> Edit</a>
                        
                           <form action="<?php echo e(route('products.destroy',$c)); ?>" method="POST" onsubmit="return confirm('Are you sure , you want to delete this?')">
                             <?php echo method_field('DELETE'); ?>
                             <?php echo csrf_field(); ?>
                             <button type="submit" class="dropdown-item" ><i class="dw dw-delete-3"></i> Delete</button>
                           </form>
                        </div>
                     </div>
                  </td>
               </tr>
               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



               
            </tbody>
         </table>
      </div>
   </div>

               




<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\durian\resources\views/admin/products/index.blade.php ENDPATH**/ ?>