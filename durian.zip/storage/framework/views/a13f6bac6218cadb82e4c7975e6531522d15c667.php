

<?php $__env->startSection('content'); ?>

<div class="pd-20 card-box mb-30">
    <div class="clearfix">
        <div class="pull-left mb-20">
            <h4 class="text-dark h4">Update User</h4>
            
        </div>
        
    </div>
    <form class="form-horizontal"  action="<?php echo e(route('users.update',$user)); ?>" method="POST">      
       <?php echo method_field('PUT'); ?>
       <?php echo csrf_field(); ?>
        <div class="form-group row">
            <label class="col-sm-12 col-md-2 col-form-label">Name</label>
            <div class="col-sm-12 col-md-10">
                <input class="form-control" type="text" value="<?php echo e($user->name); ?>" name="name" placeholder="Name">
            </div>
        </div>

        <div class="form-group row">
            <label class="col-sm-12 col-md-2 col-form-label">Email</label>
            <div class="col-sm-12 col-md-10">
                <input class="form-control" type="email" value="<?php echo e($user->email); ?>" name="email" placeholder="Email">
            </div>
        </div>

        <div class="form-group row">
            <label class="col-sm-12 col-md-2 col-form-label">Password</label>
            <div class="col-sm-12 col-md-10">
                <input class="form-control" type="password" name="password" placeholder="Password">
            </div>
        </div>

        <div class="form-group row">
            <label class="col-sm-12 col-md-2 col-form-label">Phone</label>
            <div class="col-sm-12 col-md-10">
                <input class="form-control" type="number" value="<?php echo e($user->phone); ?>" name="phone" placeholder="Phone">
            </div>
        </div>

        <div class="form-group row">
            <label class="col-sm-12 col-md-2 col-form-label">City</label>
            <div class="col-sm-12 col-md-10">
                <input class="form-control" type="text" value="<?php echo e($user->city); ?>" name="city" placeholder="City">
            </div>
        </div>

        <div class="form-group row">
            <label class="col-sm-12 col-md-2 col-form-label">Area</label>
            <div class="col-sm-12 col-md-10">
                <input class="form-control" type="text" value="<?php echo e($user->area); ?>" name="area" placeholder="Area">
            </div>
        </div>

        <div class="form-group row">
            <label class="col-sm-12 col-md-2 col-form-label">Pincode</label>
            <div class="col-sm-12 col-md-10">
                <input class="form-control" type="text" value="<?php echo e($user->pincode); ?>" name="pincode" placeholder="Pincode">
            </div>
        </div>

        <div class="form-group row">
            <label class="col-sm-12 col-md-2 col-form-label">Select Roles</label>
            <div class="col-sm-12 col-md-10">
                <select class="custom-select2 form-control" name="role_id" style="width: 100%;">
                    
                    <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($role->id); ?>" <?php echo e($role->id==$user->role_id?"selected":""); ?>><?php echo e($role->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
        </div>

        <div class="form-group row">
            <label class="col-sm-12 col-md-2 col-form-label">Status</label>
            <div class="col-sm-12 col-md-10">
                <select class="custom-select2 form-control" name="status" style="width: 100%;">
                    
                    <option value="1" <?php echo e($user->status=='1'?'Selected': ''); ?>>Active</option>
                    <option value="0" <?php echo e($user->status=='0'?'Selected': ''); ?>>Not Active</option>
                    
                </select>
            </div>
        </div>

        <button class="btn btn-success" type="submit">Update</button>

    </form>
    
</div>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\durian\resources\views/admin/users/edit.blade.php ENDPATH**/ ?>